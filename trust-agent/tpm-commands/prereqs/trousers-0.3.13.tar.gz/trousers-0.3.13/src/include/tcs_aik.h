
/*
 * Licensed Materials - Property of IBM
 *
 * trousers - An open source TCG Software Stack
 *
 * (C) Copyright International Business Machines Corp. 2006-2007
 *
 */

#ifndef _TCS_AIK_H_
#define _TCS_AIK_H_

void get_credential(UINT32, UINT32 *, BYTE **);

#endif
