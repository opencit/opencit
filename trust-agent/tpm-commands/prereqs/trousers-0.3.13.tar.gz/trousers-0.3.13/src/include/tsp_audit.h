
/*
 * Licensed Materials - Property of IBM
 *
 * trousers - An open source TCG Software Stack
 *
 * (C) Copyright International Business Machines Corp. 2007
 *
 */

#ifndef _TSP_AUDIT_H_
#define _TSP_AUDIT_H_

TSS_RESULT	   __tspi_audit_set_ordinal_audit_status(TSS_HTPM, TSS_FLAG, TSS_FLAG, UINT32);

#endif
