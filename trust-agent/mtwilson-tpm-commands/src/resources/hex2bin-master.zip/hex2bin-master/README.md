# hex2bin
Converts hex input to binary output
